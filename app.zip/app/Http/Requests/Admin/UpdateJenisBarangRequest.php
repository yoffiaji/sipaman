<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateJenisBarangRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'nama_jenis' => ['required', 'string', 'max:150', Rule::unique('jenis_barangs', 'nama_jenis')->ignore($this->route('jenisBarang')?->id)],
            'slug' => ['nullable', 'string', 'max:160', Rule::unique('jenis_barangs', 'slug')->ignore($this->route('jenisBarang')?->id)],
            'deskripsi' => ['nullable', 'string', 'max:1000'],
            'is_active' => ['sometimes', 'boolean'],
            'aliases' => ['nullable', 'string', 'max:5000'],
        ];
    }

    public function messages(): array
    {
        return [
            'nama_jenis.required' => 'Nama jenis barang wajib diisi.',
            'nama_jenis.unique' => 'Nama jenis barang sudah digunakan.',
            'slug.unique' => 'Slug jenis barang sudah digunakan.',
            'deskripsi.max' => 'Deskripsi maksimal 1000 karakter.',
            'aliases.max' => 'Daftar alias terlalu panjang.',
        ];
    }
}
