<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Http\UploadedFile;

class ImportSpreadsheetFile implements ValidationRule
{
    private const ALLOWED_MIME_TYPES = [
        'xls' => [
            'application/vnd.ms-excel',
            'application/vnd.ms-office',
            'application/x-msexcel',
            'application/x-ms-excel',
            'application/x-excel',
            'application/excel',
            'application/x-ole-storage',
            'application/cdfv2',
            'application/cdfv2-corrupt',
            'application/x-cdfv2',
            'application/octet-stream',
        ],
        'xlsx' => [
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/zip',
            'application/octet-stream',
        ],
        'csv' => [
            'text/csv',
            'text/plain',
            'application/csv',
            'application/x-csv',
            'text/x-csv',
            'text/comma-separated-values',
            'application/vnd.ms-excel',
        ],
    ];

    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        if (! $value instanceof UploadedFile) {
            $fail('File import tidak valid.');

            return;
        }

        $extension = strtolower($value->getClientOriginalExtension());

        if (! array_key_exists($extension, self::ALLOWED_MIME_TYPES)) {
            $fail('Format file tidak didukung. Gunakan file .xls, .xlsx, atau .csv.');

            return;
        }

        $mimeType = strtolower((string) $value->getMimeType());

        if (in_array($mimeType, self::ALLOWED_MIME_TYPES[$extension], true)) {
            return;
        }

        $fail('Jenis file tidak sesuai. Gunakan file Excel .xls/.xlsx atau CSV yang valid.');
    }
}
