<?php

namespace App\Services;

use App\Imports\PirtCommitmentStatusImport;
use App\Imports\ProdukImport;
use App\Models\ImportLog;
use InvalidArgumentException;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Excel as ExcelReader;
use Maatwebsite\Excel\Facades\Excel as ExcelFacade;

class ProductImportService
{
    public function importRekapPirt(UploadedFile $file): array
    {
        return $this->runImport($file, 'rekap_pirt', new ProdukImport(), 'produks');
    }

    public function importCommitmentStatus(UploadedFile $file): array
    {
        return $this->runImport($file, 'status_komitmen', new PirtCommitmentStatusImport(), 'pirt_commitment_statuses');
    }

    private function runImport(UploadedFile $file, string $tipeFile, object $import, string $tabel): array
    {
        $readerType = $this->resolveReaderType($file);

        try {
            DB::transaction(function () use ($file, $import, $readerType) {
                ExcelFacade::import($import, $file, null, $readerType);
            });
        } catch (\Throwable $e) {
            $this->createImportLog(
                file: $file,
                tipeFile: $tipeFile,
                berhasil: 0,
                gagal: 0,
                keterangan: "Tipe {$tipeFile}: import gagal. {$e->getMessage()}"
            );

            throw $e;
        }

        $berhasil = method_exists($import, 'getBerhasil') ? $import->getBerhasil() : 0;
        $gagal = method_exists($import, 'getGagal') ? $import->getGagal() : 0;
        $failures = method_exists($import, 'getFailureDetails') ? $import->getFailureDetails() : [];

        $this->createImportLog(
            file: $file,
            tipeFile: $tipeFile,
            berhasil: $berhasil,
            gagal: $gagal,
            keterangan: $gagal > 0
                ? "Tipe {$tipeFile}: {$gagal} baris gagal / tidak valid."
                : "Tipe {$tipeFile}: semua baris berhasil diimpor."
        );

        return [
            'tipe_file' => $tipeFile,
            'tabel' => $tabel,
            'nama_file' => $file->getClientOriginalName(),
            'reader_type' => $readerType,
            'berhasil' => $berhasil,
            'gagal' => $gagal,
            'failures' => $failures,
        ];
    }

    private function resolveReaderType(UploadedFile $file): string
    {
        $extension = strtolower($file->getClientOriginalExtension());

        return match ($extension) {
            'xls' => ExcelReader::XLS,
            'xlsx' => ExcelReader::XLSX,
            'csv' => ExcelReader::CSV,
            default => throw new InvalidArgumentException('Format file tidak didukung. Gunakan file .xls, .xlsx, atau .csv.'),
        };
    }

    private function createImportLog(
        UploadedFile $file,
        string $tipeFile,
        int $berhasil,
        int $gagal,
        string $keterangan
    ): void {
        ImportLog::create([
            'user_id' => auth()->id(),
            'tipe_file' => $tipeFile,
            'nama_file' => $file->getClientOriginalName(),
            'jumlah_baris' => $berhasil + $gagal,
            'jumlah_berhasil' => $berhasil,
            'jumlah_gagal' => $gagal,
            'keterangan' => $keterangan,
            'imported_at' => now(),
        ]);
    }
}
