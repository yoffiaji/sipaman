import './bootstrap';

if ('scrollRestoration' in history) {
    history.scrollRestoration = 'auto';
}

document.addEventListener('DOMContentLoaded', () => {
    initAutoResizeTextareas();
    initAdminSidebarScroll();
    clearLegacyAdminPageScrollCache();
});

function initAutoResizeTextareas() {
    document.querySelectorAll('[data-auto-resize]').forEach((textarea) => {
        const resize = () => {
            textarea.style.height = 'auto';
            textarea.style.height = `${textarea.scrollHeight}px`;
        };

        textarea.classList.add('scrollbar-none');
        textarea.style.overflow = 'hidden';

        resize();

        textarea.addEventListener('input', resize);
    });
}

function initAdminSidebarScroll() {
    const sidebar = document.getElementById('admin-sidebar-scroll');

    if (!sidebar) {
        return;
    }

    const storageKey = 'sipaman.admin.sidebar.scrollTop';
    const savedPosition = Number.parseInt(localStorage.getItem(storageKey) || '', 10);

    if (!Number.isNaN(savedPosition)) {
        sidebar.scrollTop = savedPosition;
    }

    const savePosition = () => {
        localStorage.setItem(storageKey, String(sidebar.scrollTop));
    };

    sidebar.addEventListener('scroll', savePosition);
    sidebar.addEventListener('click', savePosition);
    window.addEventListener('beforeunload', savePosition);
}

function clearLegacyAdminPageScrollCache() {
    Object.keys(localStorage)
        .filter((key) => key.startsWith('sipaman.admin.page.scrollY:'))
        .forEach((key) => localStorage.removeItem(key));
}